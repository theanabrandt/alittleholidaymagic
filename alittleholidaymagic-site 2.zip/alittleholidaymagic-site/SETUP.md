# A Little Holiday Magic: setup guide

This folder is the whole site: the sales page, the family Santa pages, the photographer dashboard, and the server functions. Follow these steps in order. Plan on about an hour.

**What goes where**

| Piece | Service | What it does |
|---|---|---|
| Website + functions | Netlify (from GitHub) | Hosts every page and runs the server code |
| Database, logins, Santa photos | Supabase (new project) | Studios, families, sign-ins |
| Email | Resend | Letters, cheat sheets, Santa's daily notes, sign-in links |
| Payments | Stripe Payment Links | $74 launch / $199 lifetime |
| Domain | Squarespace DNS | Points alittleholidaymagic.com at Netlify |

---

## 1. Supabase (new project)

1. Create a **new** project named `alittleholidaymagic`. Don't reuse another product's project.
2. **SQL Editor → New query**: paste all of `supabase/schema.sql` and click **Run**. It creates the tables, the grants, the security rules, and the `santa-photos` storage bucket.
3. At the bottom of `schema.sql` there's a commented `insert` for your own studio. Remove the `--` on those lines, check the email, and run it. You now have your own Santa page without buying.
4. **Authentication → URL Configuration**
   - Site URL: `https://alittleholidaymagic.com` (the production domain, never localhost)
   - Redirect URLs: add `https://alittleholidaymagic.com/dashboard`
5. **Authentication → Sign In / Providers → Email**: keep Email on. Magic links are what the dashboard uses.
6. **Project Settings → API**: copy the **Project URL**, the **anon public** key, and the **service_role** key. You'll need all three.

## 2. Resend (email)

1. Add the domain **mail.alittleholidaymagic.com**. Using a subdomain keeps this mail separate from anabrandt.com.
2. Resend shows DNS records (TXT for SPF/DKIM, sometimes MX). Add each one in **Squarespace → Domains → alittleholidaymagic.com → DNS**, exactly as shown. Wait for Resend to say **Verified**.
3. Create an **API key** (sending access).
4. **Supabase → Authentication → Emails → SMTP Settings**: turn on custom SMTP so sign-in links come from you and aren't rate-limited:
   - Host `smtp.resend.com`, Port `465`, Username `resend`, Password = your Resend API key
   - Sender email `santa@mail.alittleholidaymagic.com`, Sender name `A Little Holiday Magic`
5. Check Resend's plan limits. Daily notes send one email per family per day in December, so the free plan will run out quickly once studios have families.

## 3. Stripe

1. **Product catalog → Add product**: "A Little Holiday Magic: Lifetime Access". Add two one-time prices: **$74** and **$199**.
2. **Payment Links**: make one link for each price. For each link, go to **After payment**, choose "Don't show confirmation page," and redirect to `https://alittleholidaymagic.com/dashboard`.
3. **Developers → Webhooks → Add endpoint**
   - URL: `https://alittleholidaymagic.com/api/stripe-webhook`
   - Event: `checkout.session.completed`
   - Copy the **Signing secret** (starts with `whsec_`).
4. When the 24 hours are up, **deactivate the $74 payment link** in Stripe. The countdown on the page switches to $199 by itself, but anyone holding the old link could still use it until you turn it off.

## 4. GitHub + Netlify

1. Create a new GitHub repo, e.g. `alittleholidaymagic`. Upload this folder **with its folders intact**: `public/`, `netlify/`, `supabase/`, `netlify.toml`, `package.json`, and this file all at the top level of the repo. Don't flatten the folders, or the functions stop working.
2. Netlify → **Add new site → Import from GitHub** → pick the repo. The build settings come from `netlify.toml`, so there's nothing to type.
3. **Site configuration → Environment variables**: add these, then **Trigger deploy**:

| Name | Value |
|---|---|
| `SUPABASE_URL` | Supabase Project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service_role key (secret, never put it in config.js) |
| `RESEND_API_KEY` | Resend API key |
| `MAIL_FROM` | `Santa's Helpers <santa@mail.alittleholidaymagic.com>` |
| `SUPPORT_EMAIL` | where studios' replies should go, e.g. `hello@alittleholidaymagic.com` |
| `STRIPE_SECRET_KEY` | Stripe secret key (`sk_live_…`) |
| `STRIPE_WEBHOOK_SECRET` | the `whsec_…` from step 3 |
| `SITE_URL` | `https://alittleholidaymagic.com` |

## 5. Fill in `public/config.js`

Edit it in GitHub with the pencil icon. These values are public and safe to publish:

- `SUPABASE_URL` and `SUPABASE_ANON_KEY` (the **anon** key, not service_role)
- `STRIPE_LINK_LAUNCH` ($74 link) and `STRIPE_LINK_FULL` ($199 link)
- `LAUNCH_ENDS`: the moment the $74 price ends, with your time zone. For example, if you announce at 9am Pacific on Oct 14: `"2026-10-15T09:00:00-07:00"`. Leave it `""` and the page shows only $199.

Commit, and Netlify redeploys on its own.

## 6. Point the domain (Squarespace)

Squarespace undoes nameserver changes, so connect with records instead:

1. In Netlify: **Domain management → Add domain** → `alittleholidaymagic.com`. If Netlify offers to set up Netlify DNS, skip it. If a Netlify DNS zone gets created, delete it.
2. In Squarespace DNS for alittleholidaymagic.com:
   - Delete the Squarespace **A (@)** records and the **cloudfront** CNAMEs.
   - Add **A** `@` → `75.2.60.5`
   - Add **CNAME** `www` → `<your-site-name>.netlify.app`
   - Leave the Resend records from step 2 alone.
3. Back in Netlify, wait for the domain to verify, then turn on **HTTPS** (Let's Encrypt).

## 7. Test before you announce

Use Stripe **test mode** first: swap in test keys and test payment links, then switch back to live.

- [ ] `/demo` loads, the chat runs, and the grown-ups door opens
- [ ] Buy with a test card (4242 4242 4242 4242) → the welcome email arrives
- [ ] `/dashboard` → sign in with that email → set your link, name, and a Santa day → **Save**
- [ ] Open your page, finish the chat, and send the grown-ups form to your own email → the family email and the cheat sheet both arrive
- [ ] Try the `?visit=1` link from the Share tab → Santa mentions the visit day
- [ ] Buy again with the **same** email → no error, still one studio
- [ ] Upload a Santa photo in the dashboard → Save → it shows on your page
- [ ] Unsubscribe link in the family email → "Santa's daily notes are turned off"

## How the daily notes run

`netlify/functions/daily-notes.mjs` runs on a schedule every hour from 14:00 to 20:00 UTC (6am Pacific / 9am Eastern onward), December 1 to 24. Each family gets exactly one note a day, and later runs pick up anyone left over. Scheduled functions only run on your **published production** deploy. You can see each run under **Netlify → Logs → Functions → daily-notes**.

## Before launch

- Have a lawyer review `public/privacy.html`, especially the children's privacy section. The site is built so a child's answers stay on the device unless a parent sends them, but the policy wording still needs a professional check.
- Set up the `hello@alittleholidaymagic.com` mailbox (or change it in `privacy.html`).
- Each December, update the gift list (`GIFTS` in `public/js/content.js`).
